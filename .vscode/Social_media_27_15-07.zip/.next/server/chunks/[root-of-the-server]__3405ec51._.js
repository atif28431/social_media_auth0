module.exports = {

"[project]/.next-internal/server/app/api/facebook/token/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/stream [external] (stream, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}}),
"[externals]/http [external] (http, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}}),
"[externals]/url [external] (url, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}}),
"[externals]/punycode [external] (punycode, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("punycode", () => require("punycode"));

module.exports = mod;
}}),
"[externals]/https [external] (https, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}}),
"[externals]/zlib [external] (zlib, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}}),
"[externals]/events [external] (events, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}}),
"[externals]/net [external] (net, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("net", () => require("net"));

module.exports = mod;
}}),
"[externals]/tls [external] (tls, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("tls", () => require("tls"));

module.exports = mod;
}}),
"[externals]/crypto [external] (crypto, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}}),
"[externals]/buffer [external] (buffer, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}}),
"[project]/src/app/api/facebook/token/route.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// pages/api/facebook/token.js or app/api/facebook/token/route.js
__turbopack_context__.s({
    "POST": (()=>POST),
    "default": (()=>handler)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/module/index.js [app-route] (ecmascript) <locals>");
;
// Initialize Supabase client
const supabaseUrl = ("TURBOPACK compile-time value", "https://ububohnboqcftnfgflpd.supabase.co");
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY; // Use service role key for server-side operations
const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(supabaseUrl, supabaseServiceKey);
async function POST(request) {
    try {
        const { access_token, user_id } = await request.json();
        console.log('📝 Storing Facebook token for user:', user_id);
        console.log('🔑 Token (first 20 chars):', access_token?.substring(0, 20) + '...');
        if (!access_token || !user_id) {
            return Response.json({
                error: 'Missing access_token or user_id'
            }, {
                status: 400
            });
        }
        // Check if user session already exists
        const { data: existingSession, error: fetchError } = await supabase.from('user_sessions').select('id').eq('user_id', user_id).single();
        if (fetchError && fetchError.code !== 'PGRST116') {
            console.error('❌ Error checking existing session:', fetchError);
            return Response.json({
                error: 'Database error while checking session'
            }, {
                status: 500
            });
        }
        let result;
        const sessionData = {
            facebook_access_token: access_token,
            updated_at: new Date().toISOString()
        };
        if (existingSession) {
            // Update existing session
            console.log('🔄 Updating existing session...');
            const { data, error } = await supabase.from('user_sessions').update(sessionData).eq('user_id', user_id).select();
            result = {
                data,
                error
            };
        } else {
            // Create new session
            console.log('➕ Creating new session...');
            const { data, error } = await supabase.from('user_sessions').insert({
                user_id,
                ...sessionData,
                created_at: new Date().toISOString()
            }).select();
            result = {
                data,
                error
            };
        }
        if (result.error) {
            console.error('❌ Supabase error:', result.error);
            return Response.json({
                error: 'Failed to store token in database',
                details: result.error.message
            }, {
                status: 500
            });
        }
        console.log('✅ Token stored successfully');
        return Response.json({
            success: true,
            data: result.data
        });
    } catch (error) {
        console.error('❌ Unexpected error in Facebook token API:', error);
        return Response.json({
            error: 'Internal server error',
            details: error.message
        }, {
            status: 500
        });
    }
}
async function handler(req, res) {
    if (req.method !== 'POST') {
        return res.status(405).json({
            error: 'Method not allowed'
        });
    }
    try {
        const { access_token, user_id } = req.body;
        console.log('📝 Storing Facebook token for user:', user_id);
        console.log('🔑 Token (first 20 chars):', access_token?.substring(0, 20) + '...');
        if (!access_token || !user_id) {
            return res.status(400).json({
                error: 'Missing access_token or user_id'
            });
        }
        // Check if user session already exists
        const { data: existingSession, error: fetchError } = await supabase.from('user_sessions').select('id').eq('user_id', user_id).single();
        if (fetchError && fetchError.code !== 'PGRST116') {
            console.error('❌ Error checking existing session:', fetchError);
            return res.status(500).json({
                error: 'Database error while checking session'
            });
        }
        let result;
        const sessionData = {
            facebook_access_token: access_token,
            updated_at: new Date().toISOString()
        };
        if (existingSession) {
            // Update existing session
            console.log('🔄 Updating existing session...');
            const { data, error } = await supabase.from('user_sessions').update(sessionData).eq('user_id', user_id).select();
            result = {
                data,
                error
            };
        } else {
            // Create new session
            console.log('➕ Creating new session...');
            const { data, error } = await supabase.from('user_sessions').insert({
                user_id,
                ...sessionData,
                created_at: new Date().toISOString()
            }).select();
            result = {
                data,
                error
            };
        }
        if (result.error) {
            console.error('❌ Supabase error:', result.error);
            return res.status(500).json({
                error: 'Failed to store token in database',
                details: result.error.message
            });
        }
        console.log('✅ Token stored successfully');
        return res.status(200).json({
            success: true,
            data: result.data
        });
    } catch (error) {
        console.error('❌ Unexpected error in Facebook token API:', error);
        return res.status(500).json({
            error: 'Internal server error',
            details: error.message
        });
    }
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__3405ec51._.js.map
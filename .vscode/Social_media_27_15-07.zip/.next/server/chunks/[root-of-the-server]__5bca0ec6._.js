module.exports = {

"[project]/.next-internal/server/app/api/auth/youtube-callback/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/stream [external] (stream, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}}),
"[externals]/http [external] (http, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}}),
"[externals]/url [external] (url, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}}),
"[externals]/punycode [external] (punycode, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("punycode", () => require("punycode"));

module.exports = mod;
}}),
"[externals]/https [external] (https, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}}),
"[externals]/zlib [external] (zlib, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}}),
"[externals]/events [external] (events, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}}),
"[externals]/net [external] (net, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("net", () => require("net"));

module.exports = mod;
}}),
"[externals]/tls [external] (tls, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("tls", () => require("tls"));

module.exports = mod;
}}),
"[externals]/crypto [external] (crypto, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}}),
"[externals]/buffer [external] (buffer, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}}),
"[project]/src/app/api/auth/youtube-callback/route.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "GET": (()=>GET)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/module/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/headers.js [app-route] (ecmascript)");
;
;
;
async function GET(request) {
    try {
        // Get the authorization code and state from the request
        const { searchParams } = new URL(request.url);
        const code = searchParams.get('code');
        const state = searchParams.get('state');
        const error = searchParams.get('error');
        // Check if there was an error in the OAuth process
        if (error) {
            console.error('YouTube OAuth error:', error);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].redirect(`${process.env.APP_BASE_URL}/youtube?error=${encodeURIComponent(error)}`);
        }
        // Verify the state parameter to prevent CSRF attacks
        const cookieStore = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["cookies"])();
        const storedState = cookieStore.get('youtube_auth_state')?.value;
        if (!storedState || state !== storedState) {
            console.error('Invalid state parameter');
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].redirect(`${process.env.APP_BASE_URL}/youtube?error=${encodeURIComponent('Invalid state parameter')}`);
        }
        // Get the user session from the id_token cookie
        const idToken = cookieStore.get('id_token')?.value;
        if (!idToken) {
            console.error('No user session found');
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].redirect(`${process.env.APP_BASE_URL}/login?error=${encodeURIComponent('Please log in to connect your YouTube account')}`);
        }
        // Decode the JWT token to get user info
        let userId;
        try {
            const payload = JSON.parse(atob(idToken.split('.')[1]));
            userId = payload.sub;
            console.log('User ID from token:', userId);
        } catch (decodeError) {
            console.error('Error decoding token:', decodeError);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].redirect(`${process.env.APP_BASE_URL}/login?error=${encodeURIComponent('Invalid session. Please log in again.')}`);
        }
        // Exchange the authorization code for access and refresh tokens
        const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams({
                code,
                client_id: process.env.GOOGLE_CLIENT_ID,
                client_secret: process.env.GOOGLE_CLIENT_SECRET,
                redirect_uri: `${process.env.APP_BASE_URL}/api/auth/youtube-callback`,
                grant_type: 'authorization_code'
            })
        });
        if (!tokenResponse.ok) {
            const errorData = await tokenResponse.json();
            console.error('Error exchanging code for tokens:', errorData);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].redirect(`${process.env.APP_BASE_URL}/youtube?error=${encodeURIComponent('Failed to exchange code for tokens')}`);
        }
        const tokenData = await tokenResponse.json();
        const { access_token, refresh_token, expires_in } = tokenData;
        // Calculate token expiry time (current time + expires_in seconds)
        const expiresAt = new Date(Date.now() + expires_in * 1000).toISOString();
        // Get user information from the YouTube API
        const userResponse = await fetch('https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true', {
            headers: {
                Authorization: `Bearer ${access_token}`
            }
        });
        if (!userResponse.ok) {
            const errorData = await userResponse.json();
            console.error('Error fetching YouTube user data:', errorData);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].redirect(`${process.env.APP_BASE_URL}/youtube?error=${encodeURIComponent('Failed to fetch YouTube user data')}`);
        }
        const userData = await userResponse.json();
        const channel = userData.items[0];
        // Create Supabase client with service role key for server-side operations
        const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(("TURBOPACK compile-time value", "https://ububohnboqcftnfgflpd.supabase.co"), process.env.SUPABASE_SERVICE_ROLE_KEY);
        // Update the user_sessions table with YouTube tokens
        const { error: sessionUpdateError } = await supabase.from('user_sessions').upsert({
            user_id: userId,
            youtube_access_token: access_token,
            youtube_refresh_token: refresh_token,
            youtube_token_expires_at: expiresAt,
            updated_at: new Date().toISOString()
        }, {
            onConflict: 'user_id'
        });
        if (sessionUpdateError) {
            console.error('Error updating user session:', sessionUpdateError);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].redirect(`${process.env.APP_BASE_URL}/youtube?error=${encodeURIComponent('Failed to store YouTube tokens')}`);
        }
        // Insert the YouTube channel into the youtube_accounts table
        if (!channel) {
            console.warn('No YouTube channel found for this account');
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].redirect(`${process.env.APP_BASE_URL}/youtube?error=${encodeURIComponent('No YouTube channel found for this account')}`);
        }
        console.log('Session updated successfully');
        // Insert the YouTube channel into the youtube_accounts table
        // First, let's try to insert with the unique constraint on youtube_channel_id
        const { data: existingChannel, error: checkError } = await supabase.from('youtube_accounts').select('id, user_id').eq('youtube_channel_id', channel.id).single();
        if (checkError && checkError.code !== 'PGRST116') {
            console.error('Error checking existing channel:', checkError);
        }
        let channelInsertError = null;
        if (existingChannel) {
            // Channel exists, update it
            const { error: updateError } = await supabase.from('youtube_accounts').update({
                user_id: userId,
                channel_name: channel.snippet.title,
                channel_description: channel.snippet.description,
                profile_picture_url: channel.snippet.thumbnails?.default?.url,
                access_token: access_token,
                refresh_token: refresh_token,
                token_expires_at: expiresAt,
                updated_at: new Date().toISOString()
            }).eq('youtube_channel_id', channel.id);
            channelInsertError = updateError;
            if (!updateError) {
                console.log('YouTube channel updated successfully');
            }
        } else {
            // Channel doesn't exist, insert it
            const { error: insertError } = await supabase.from('youtube_accounts').insert({
                user_id: userId,
                youtube_channel_id: channel.id,
                channel_name: channel.snippet.title,
                channel_description: channel.snippet.description,
                profile_picture_url: channel.snippet.thumbnails?.default?.url,
                access_token: access_token,
                refresh_token: refresh_token,
                token_expires_at: expiresAt,
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString()
            });
            channelInsertError = insertError;
            if (!insertError) {
                console.log('YouTube channel inserted successfully');
            }
        }
        if (channelInsertError) {
            console.error('Error inserting/updating YouTube channel:', channelInsertError);
            // Continue anyway, as we've already stored the tokens
            console.log('Continuing despite channel insert/update error...');
        }
        // Check if there's a return parameter to determine where to redirect
        const returnParam = cookieStore.get('youtube_return_url')?.value;
        let redirectUrl = `${process.env.APP_BASE_URL}/youtube?success=true`;
        if (returnParam === 'settings') {
            redirectUrl = `${process.env.APP_BASE_URL}/settings?success=true`;
        }
        // Clear the state and return URL cookies
        const response = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].redirect(redirectUrl);
        response.cookies.set('youtube_auth_state', '', {
            httpOnly: true,
            secure: ("TURBOPACK compile-time value", "development") === 'production',
            maxAge: 0,
            path: '/'
        });
        response.cookies.set('youtube_return_url', '', {
            httpOnly: true,
            secure: ("TURBOPACK compile-time value", "development") === 'production',
            maxAge: 0,
            path: '/'
        });
        return response;
    } catch (error) {
        console.error('Error handling YouTube callback:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].redirect(`${process.env.APP_BASE_URL}/youtube?error=${encodeURIComponent('An unexpected error occurred')}`);
    }
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__5bca0ec6._.js.map
module.exports = {

"[project]/.next-internal/server/app/api/upload/media/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/stream [external] (stream, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}}),
"[externals]/http [external] (http, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}}),
"[externals]/url [external] (url, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}}),
"[externals]/punycode [external] (punycode, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("punycode", () => require("punycode"));

module.exports = mod;
}}),
"[externals]/https [external] (https, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}}),
"[externals]/zlib [external] (zlib, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}}),
"[externals]/events [external] (events, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}}),
"[externals]/net [external] (net, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("net", () => require("net"));

module.exports = mod;
}}),
"[externals]/tls [external] (tls, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("tls", () => require("tls"));

module.exports = mod;
}}),
"[externals]/crypto [external] (crypto, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}}),
"[externals]/buffer [external] (buffer, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/app/api/upload/media/route.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "DELETE": (()=>DELETE),
    "GET": (()=>GET),
    "POST": (()=>POST)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/module/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
;
;
const supabaseUrl = ("TURBOPACK compile-time value", "https://ububohnboqcftnfgflpd.supabase.co");
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
// Supported file types
const SUPPORTED_IMAGE_TYPES = [
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp'
];
const SUPPORTED_VIDEO_TYPES = [
    'video/mp4',
    'video/quicktime',
    'video/mpeg',
    'video/webm'
];
const MAX_FILE_SIZE = 100 * 1024 * 1024; // 100MB limit for videos
async function POST(request) {
    try {
        console.log('📤 Starting media upload process...');
        // Check environment variables
        if (!supabaseUrl || !supabaseServiceKey) {
            console.error('❌ Missing environment variables:', {
                supabaseUrl: !!supabaseUrl,
                supabaseServiceKey: !!supabaseServiceKey
            });
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Server configuration error: Missing Supabase credentials'
            }, {
                status: 500
            });
        }
        const formData = await request.formData();
        const file = formData.get('file');
        const userId = formData.get('userId');
        const platform = formData.get('platform') || 'facebook';
        const mediaType = formData.get('mediaType') || 'image';
        console.log('📋 Upload parameters:', {
            fileName: file?.name,
            fileSize: file?.size,
            fileType: file?.type,
            userId,
            platform,
            mediaType
        });
        if (!file) {
            console.error('❌ No file provided');
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'No file provided'
            }, {
                status: 400
            });
        }
        if (!userId) {
            console.error('❌ No user ID provided');
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'User ID required'
            }, {
                status: 400
            });
        }
        // Validate file type
        const isImage = SUPPORTED_IMAGE_TYPES.includes(file.type);
        const isVideo = SUPPORTED_VIDEO_TYPES.includes(file.type);
        if (!isImage && !isVideo) {
            console.error('❌ Unsupported file type:', file.type);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Unsupported file type. Please upload an image (JPEG, PNG, GIF, WebP) or video (MP4, MOV, MPEG, WebM)'
            }, {
                status: 400
            });
        }
        // Validate file size (100MB limit for videos, 10MB for images)
        const maxSize = isVideo ? MAX_FILE_SIZE : 10 * 1024 * 1024;
        if (file.size > maxSize) {
            console.error('❌ File too large:', file.size, 'bytes, max:', maxSize);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: `File size must be less than ${isVideo ? '100MB' : '10MB'}`
            }, {
                status: 400
            });
        }
        // Create Supabase client
        console.log('🔧 Creating Supabase client...');
        const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(supabaseUrl, supabaseServiceKey, {
            auth: {
                autoRefreshToken: false,
                persistSession: false
            }
        });
        // Sanitize user ID for file path (remove invalid characters)
        const sanitizedUserId = userId.replace(/[^a-zA-Z0-9-_]/g, '_');
        // Generate unique filename
        const fileExt = file.name.split('.').pop();
        const detectedMediaType = isVideo ? 'video' : 'image';
        const fileName = `${sanitizedUserId}/${platform}/${detectedMediaType}/${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
        console.log('📁 Generated filename:', fileName);
        // Convert file to buffer
        console.log('🔄 Converting file to buffer...');
        const bytes = await file.arrayBuffer();
        const buffer = Buffer.from(bytes);
        // Determine the correct storage bucket based on media type
        const storageBucket = isVideo ? 'facebook-videos' : 'social-media-images';
        console.log('🗄️ Using storage bucket:', storageBucket);
        // Upload to Supabase Storage
        console.log('☁️ Uploading to Supabase Storage...');
        const { data: uploadData, error: uploadError } = await supabase.storage.from(storageBucket).upload(fileName, buffer, {
            contentType: file.type,
            upsert: false
        });
        if (uploadError) {
            console.error('❌ Upload error:', uploadError);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: `Failed to upload file: ${uploadError.message}`
            }, {
                status: 500
            });
        }
        console.log('✅ Upload successful:', uploadData);
        // Get public URL
        console.log('🔗 Getting public URL...');
        const { data: urlData } = supabase.storage.from(storageBucket).getPublicUrl(fileName);
        console.log('🌐 Public URL:', urlData.publicUrl);
        // Save media record to database
        console.log('💾 Saving record to database...');
        const { data: dbData, error: dbError } = await supabase.from('uploaded_media').insert({
            user_id: userId,
            platform: platform,
            file_name: fileName,
            original_name: file.name,
            file_size: file.size,
            file_type: file.type,
            media_type: mediaType,
            storage_path: uploadData.path,
            storage_bucket: storageBucket,
            public_url: urlData.publicUrl,
            created_at: new Date().toISOString()
        }).select().single();
        if (dbError) {
            console.error('❌ Database error:', dbError);
            // Try to clean up uploaded file
            console.log('🧹 Cleaning up uploaded file...');
            await supabase.storage.from(storageBucket).remove([
                fileName
            ]);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: `Failed to save media record: ${dbError.message}`
            }, {
                status: 500
            });
        }
        console.log('✅ Database record saved:', dbData);
        const response = {
            success: true,
            media: {
                id: dbData.id,
                fileName: fileName,
                originalName: file.name,
                publicUrl: urlData.publicUrl,
                public_url: urlData.publicUrl,
                fileSize: file.size,
                fileType: file.type,
                mediaType: mediaType
            }
        };
        console.log('🎉 Upload complete, returning response:', response);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(response);
    } catch (error) {
        console.error('❌ Media upload error:', error);
        console.error('Stack trace:', error.stack);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: `Internal server error: ${error.message}`
        }, {
            status: 500
        });
    }
}
async function GET(request) {
    try {
        console.log('📥 Starting media fetch process...');
        const { searchParams } = new URL(request.url);
        const userId = searchParams.get('userId');
        const platform = searchParams.get('platform');
        const mediaType = searchParams.get('mediaType');
        console.log('📋 Fetch parameters:', {
            userId,
            platform,
            mediaType
        });
        if (!userId) {
            console.error('❌ No user ID provided');
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'User ID required'
            }, {
                status: 400
            });
        }
        // Check environment variables
        if (!supabaseUrl || !supabaseServiceKey) {
            console.error('❌ Missing environment variables');
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Server configuration error: Missing Supabase credentials'
            }, {
                status: 500
            });
        }
        const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(supabaseUrl, supabaseServiceKey, {
            auth: {
                autoRefreshToken: false,
                persistSession: false
            }
        });
        let query = supabase.from('uploaded_media').select('*').eq('user_id', userId).order('created_at', {
            ascending: false
        });
        if (platform) {
            query = query.eq('platform', platform);
        }
        if (mediaType) {
            query = query.eq('media_type', mediaType);
        }
        console.log('🔍 Executing database query...');
        const { data, error } = await query;
        if (error) {
            console.error('❌ Database error:', error);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: `Failed to fetch media: ${error.message}`
            }, {
                status: 500
            });
        }
        console.log('✅ Found', data?.length || 0, 'media items');
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            media: data || []
        });
    } catch (error) {
        console.error('❌ Get media error:', error);
        console.error('Stack trace:', error.stack);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: `Internal server error: ${error.message}`
        }, {
            status: 500
        });
    }
}
async function DELETE(request) {
    try {
        console.log('🗑️ Starting media deletion process...');
        const { searchParams } = new URL(request.url);
        const mediaId = searchParams.get('mediaId');
        const userId = searchParams.get('userId');
        console.log('📋 Delete parameters:', {
            mediaId,
            userId
        });
        if (!mediaId || !userId) {
            console.error('❌ Missing required parameters');
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Media ID and User ID required'
            }, {
                status: 400
            });
        }
        // Check environment variables
        if (!supabaseUrl || !supabaseServiceKey) {
            console.error('❌ Missing environment variables');
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Server configuration error: Missing Supabase credentials'
            }, {
                status: 500
            });
        }
        const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(supabaseUrl, supabaseServiceKey, {
            auth: {
                autoRefreshToken: false,
                persistSession: false
            }
        });
        // Get media record
        console.log('🔍 Fetching media record...');
        const { data: mediaData, error: fetchError } = await supabase.from('uploaded_media').select('*').eq('id', mediaId).eq('user_id', userId).single();
        if (fetchError || !mediaData) {
            console.error('❌ Media not found:', fetchError);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Media not found'
            }, {
                status: 404
            });
        }
        console.log('✅ Media record found:', mediaData.file_name);
        // Determine the correct storage bucket
        const storageBucket = mediaData.storage_bucket || (mediaData.file_type.startsWith('video/') ? 'facebook-videos' : 'social-media-images');
        // Delete from storage
        console.log('🗑️ Deleting from storage bucket:', storageBucket);
        const { error: storageError } = await supabase.storage.from(storageBucket).remove([
            mediaData.file_name
        ]);
        if (storageError) {
            console.error('⚠️ Storage deletion error:', storageError);
        }
        // Delete from database
        console.log('🗑️ Deleting from database...');
        const { error: dbError } = await supabase.from('uploaded_media').delete().eq('id', mediaId).eq('user_id', userId);
        if (dbError) {
            console.error('❌ Database deletion error:', dbError);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: `Failed to delete media record: ${dbError.message}`
            }, {
                status: 500
            });
        }
        console.log('✅ Media deleted successfully');
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true
        });
    } catch (error) {
        console.error('❌ Delete media error:', error);
        console.error('Stack trace:', error.stack);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: `Internal server error: ${error.message}`
        }, {
            status: 500
        });
    }
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__18e7ab35._.js.map
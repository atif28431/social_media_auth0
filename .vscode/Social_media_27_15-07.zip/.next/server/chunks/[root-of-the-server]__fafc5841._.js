module.exports = {

"[project]/.next-internal/server/app/api/instagram/token/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/stream [external] (stream, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}}),
"[externals]/http [external] (http, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}}),
"[externals]/url [external] (url, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}}),
"[externals]/punycode [external] (punycode, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("punycode", () => require("punycode"));

module.exports = mod;
}}),
"[externals]/https [external] (https, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}}),
"[externals]/zlib [external] (zlib, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}}),
"[externals]/events [external] (events, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}}),
"[externals]/net [external] (net, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("net", () => require("net"));

module.exports = mod;
}}),
"[externals]/tls [external] (tls, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("tls", () => require("tls"));

module.exports = mod;
}}),
"[externals]/crypto [external] (crypto, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}}),
"[externals]/buffer [external] (buffer, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/app/api/instagram/token/route.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "POST": (()=>POST)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/module/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/headers.js [app-route] (ecmascript)");
;
;
async function POST(request) {
    try {
        const { code, user_id, redirect_uri } = await request.json();
        if (!code) {
            return new Response(JSON.stringify({
                error: "Authorization code is required"
            }), {
                status: 400,
                headers: {
                    'Content-Type': 'application/json'
                }
            });
        }
        // Use the redirect URI from the request body if provided, otherwise construct from headers
        const redirectUri = redirect_uri || `${request.headers.get('origin') || request.headers.get('referer')?.split('/').slice(0, 3).join('/') || 'http://localhost:3000'}/instagram-callback`;
        console.log('Instagram Graph API token exchange - All headers:', Object.fromEntries(request.headers.entries()));
        console.log('Instagram Graph API token exchange - Request body redirect_uri:', redirect_uri);
        console.log('Instagram Graph API token exchange - Final redirect URI:', redirectUri);
        console.log('Instagram Graph API token exchange - Code:', code);
        // Step 1: Exchange the code for a short-lived Facebook access token
        const tokenResponse = await fetch('https://graph.facebook.com/v18.0/oauth/access_token', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams({
                client_id: ("TURBOPACK compile-time value", "690059697267024"),
                client_secret: process.env.FACEBOOK_APP_SECRET,
                redirect_uri: redirectUri,
                code
            }).toString()
        });
        const tokenData = await tokenResponse.json();
        console.log('Facebook token exchange response:', tokenData);
        if (!tokenResponse.ok || tokenData.error) {
            console.error('Facebook token exchange error:', tokenData);
            return new Response(JSON.stringify({
                error: tokenData.error_message || tokenData.error?.message || 'Failed to exchange token',
                details: tokenData
            }), {
                status: tokenResponse.status || 400,
                headers: {
                    'Content-Type': 'application/json'
                }
            });
        }
        // Step 2: Get user's Instagram Business Account ID
        const meResponse = await fetch(`https://graph.facebook.com/v18.0/me?fields=id,name&access_token=${tokenData.access_token}`);
        const meData = await meResponse.json();
        console.log('Facebook user data:', meData);
        if (!meResponse.ok || meData.error) {
            console.error('Facebook user data error:', meData);
            return new Response(JSON.stringify({
                error: 'Failed to get user data',
                details: meData
            }), {
                status: meResponse.status || 400,
                headers: {
                    'Content-Type': 'application/json'
                }
            });
        }
        // Step 3: Get Instagram Business Accounts connected to this Facebook user
        const accountsResponse = await fetch(`https://graph.facebook.com/v18.0/${meData.id}/accounts?fields=instagram_business_account&access_token=${tokenData.access_token}`);
        const accountsData = await accountsResponse.json();
        console.log('Facebook pages with Instagram accounts:', accountsData);
        if (!accountsResponse.ok || accountsData.error) {
            console.error('Facebook accounts error:', accountsData);
            return new Response(JSON.stringify({
                error: 'Failed to get Instagram business accounts',
                details: accountsData
            }), {
                status: accountsResponse.status || 400,
                headers: {
                    'Content-Type': 'application/json'
                }
            });
        }
        // Find the first Instagram Business Account
        let instagramAccountId = null;
        for (const page of accountsData.data || []){
            if (page.instagram_business_account) {
                instagramAccountId = page.instagram_business_account.id;
                break;
            }
        }
        if (!instagramAccountId) {
            return new Response(JSON.stringify({
                error: 'No Instagram Business Account found. Please ensure you have an Instagram Business Account connected to a Facebook Page.',
                details: accountsData
            }), {
                status: 400,
                headers: {
                    'Content-Type': 'application/json'
                }
            });
        }
        // Step 4: Exchange for a long-lived token
        const longLivedTokenResponse = await fetch(`https://graph.facebook.com/v18.0/oauth/access_token?grant_type=fb_exchange_token&client_id=${("TURBOPACK compile-time value", "690059697267024")}&client_secret=${process.env.FACEBOOK_APP_SECRET}&fb_exchange_token=${tokenData.access_token}`);
        const longLivedTokenData = await longLivedTokenResponse.json();
        console.log('Long-lived token response:', longLivedTokenData);
        if (!longLivedTokenResponse.ok || longLivedTokenData.error) {
            console.error('Long-lived token error:', longLivedTokenData);
            // If long-lived token fails, we can still use the short-lived token
            console.log('Using short-lived token as fallback');
        }
        const finalAccessToken = longLivedTokenData.access_token || tokenData.access_token;
        const expiresIn = longLivedTokenData.expires_in || tokenData.expires_in || 3600; // Default 1 hour
        // Store the token in Supabase
        const cookieStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["cookies"])();
        const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(("TURBOPACK compile-time value", "https://ububohnboqcftnfgflpd.supabase.co"), ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVidWJvaG5ib3FjZnRuZmdmbHBkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDg1MjI3ODEsImV4cCI6MjA2NDA5ODc4MX0.ISomr__boxC6zsAydWL2m6Nb_0Q2wwb_m0HwApA_tL4"), {
            cookies: {
                get (name) {
                    return cookieStore.get(name)?.value;
                }
            }
        });
        if (!user_id) {
            return new Response(JSON.stringify({
                error: 'User ID is required'
            }), {
                status: 400,
                headers: {
                    'Content-Type': 'application/json'
                }
            });
        }
        // Update the user's Instagram access token in user_sessions table
        const { error: updateError } = await supabase.from('user_sessions').upsert({
            user_id: user_id,
            instagram_access_token: finalAccessToken,
            instagram_token_expires_at: new Date(Date.now() + expiresIn * 1000).toISOString(),
            updated_at: new Date().toISOString()
        });
        if (updateError) {
            console.error('Supabase update error:', updateError);
            return new Response(JSON.stringify({
                error: 'Failed to store token'
            }), {
                status: 500,
                headers: {
                    'Content-Type': 'application/json'
                }
            });
        }
        return new Response(JSON.stringify({
            access_token: finalAccessToken,
            instagram_account_id: instagramAccountId,
            expires_in: expiresIn
        }), {
            status: 200,
            headers: {
                'Content-Type': 'application/json'
            }
        });
    } catch (error) {
        console.error('Instagram Graph API token exchange error:', error);
        return new Response(JSON.stringify({
            error: error.message || 'Internal server error'
        }), {
            status: 500,
            headers: {
                'Content-Type': 'application/json'
            }
        });
    }
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__fafc5841._.js.map
module.exports = {

"[project]/.next-internal/server/app/api/instagram/token/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/stream [external] (stream, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}}),
"[externals]/http [external] (http, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}}),
"[externals]/url [external] (url, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}}),
"[externals]/punycode [external] (punycode, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("punycode", () => require("punycode"));

module.exports = mod;
}}),
"[externals]/https [external] (https, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}}),
"[externals]/zlib [external] (zlib, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}}),
"[externals]/events [external] (events, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}}),
"[externals]/net [external] (net, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("net", () => require("net"));

module.exports = mod;
}}),
"[externals]/tls [external] (tls, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("tls", () => require("tls"));

module.exports = mod;
}}),
"[externals]/crypto [external] (crypto, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}}),
"[externals]/buffer [external] (buffer, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}}),
"[project]/src/lib/supabase/client.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "createClient": (()=>createClient)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/ssr/dist/module/index.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@supabase/ssr/dist/module/createBrowserClient.js [app-route] (ecmascript)");
;
const createClient = (accessToken)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createBrowserClient"])(("TURBOPACK compile-time value", "https://ububohnboqcftnfgflpd.supabase.co"), ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVidWJvaG5ib3FjZnRuZmdmbHBkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDg1MjI3ODEsImV4cCI6MjA2NDA5ODc4MX0.ISomr__boxC6zsAydWL2m6Nb_0Q2wwb_m0HwApA_tL4"), {
        global: {
            headers: {
                ...accessToken && {
                    Authorization: `Bearer ${accessToken}`
                }
            }
        }
    });
};
}}),
"[project]/src/app/api/instagram/token/route.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "POST": (()=>POST)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/supabase/client.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jwt$2d$decode$2f$build$2f$esm$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jwt-decode/build/esm/index.js [app-route] (ecmascript)");
;
;
// --- Instagram API Helper Functions ---
// These functions implement the multi-step process for posting media to Instagram.
/**
 * Creates a media container for an image post.
 * @param {string} igUserId - The user's Instagram Business Account ID.
 * @param {string} imageUrl - The publicly accessible URL of the image.
 * @param {string} caption - The caption for the post.
 * @param {string} accessToken - The user's page access token.
 * @returns {Promise<string>} - The ID of the created media container.
 */ async function createMediaContainer(igUserId, imageUrl, caption, accessToken) {
    const url = `https://graph.facebook.com/v19.0/${igUserId}/media`;
    const params = new URLSearchParams({
        image_url: imageUrl,
        caption: caption,
        access_token: accessToken
    });
    const response = await fetch(`${url}?${params.toString()}`, {
        method: 'POST'
    });
    const data = await response.json();
    if (data.error) {
        throw new Error(`[${data.error.code}] ${data.error.message}`);
    }
    return data.id;
}
/**
 * Checks the status of a media container.
 * @param {string} creationId - The ID of the media container.
 * @param {string} accessToken - The access token.
 * @returns {Promise<string>} - The status code of the container (e.g., "IN_PROGRESS", "FINISHED").
 */ async function checkContainerStatus(creationId, accessToken) {
    const response = await fetch(`https://graph.facebook.com/v19.0/${creationId}?fields=status_code&access_token=${accessToken}`);
    const data = await response.json();
    if (data.error) {
        throw new Error(`[${data.error.code}] ${data.error.message}`);
    }
    return data.status_code;
}
/**
 * Publishes a media container.
 * @param {string} igUserId - The user's Instagram Business Account ID.
 * @param {string} creationId - The ID of the media container.
 * @param {string} accessToken - The user's page access token.
 * @returns {Promise<object>} - The response from the publish API call.
 */ async function publishMedia(igUserId, creationId, accessToken) {
    const url = `https://graph.facebook.com/v19.0/${igUserId}/media_publish`;
    const params = new URLSearchParams({
        creation_id: creationId,
        access_token: accessToken
    });
    const response = await fetch(`${url}?${params.toString()}`, {
        method: 'POST'
    });
    const data = await response.json();
    if (data.error) {
        throw new Error(`[${data.error.code}] ${data.error.message}`);
    }
    return data;
}
/**
 * Orchestrates the full image posting flow for Instagram.
 * @param {string} igUserId - The user's Instagram Business Account ID.
 * @param {string} imageUrl - The publicly accessible URL of the image.
 * @param {string} caption - The caption for the post.
 * @param {string} accessToken - The user's page access token.
 * @returns {Promise<object>} - The final response from the publish API call.
 */ async function postImageToInstagram(igUserId, imageUrl, caption, accessToken) {
    // Step 1: Create a media container
    const creationId = await createMediaContainer(igUserId, imageUrl, caption, accessToken);
    // Step 2: Poll for the container to be ready
    let status = "";
    for(let i = 0; i < 15; i++){
        await new Promise((resolve)=>setTimeout(resolve, 2000)); // Wait 2 seconds between checks
        status = await checkContainerStatus(creationId, accessToken);
        if (status === "FINISHED") break;
        if (status === "ERROR") throw new Error('Media container processing failed.');
    }
    if (status !== "FINISHED") {
        throw new Error("Media container did not finish processing in time.");
    }
    // Step 3: Publish the container
    return await publishMedia(igUserId, creationId, accessToken);
}
async function POST(request) {
    try {
        // 1. Authenticate the user and get their ID from the JWT
        const authHeader = request.headers.get('authorization');
        const jwtToken = authHeader?.replace('Bearer ', '');
        if (!jwtToken) {
            return new Response(JSON.stringify({
                error: 'Not authenticated'
            }), {
                status: 401
            });
        }
        const decoded = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jwt$2d$decode$2f$build$2f$esm$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["jwtDecode"])(jwtToken);
        const userId = decoded.sub;
        if (!userId) {
            return new Response(JSON.stringify({
                error: 'Invalid token: User ID not found'
            }), {
                status: 401
            });
        }
        // 2. Initialize the Supabase client with the user's token
        const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createClient"])(jwtToken);
        // 3. Get the image URL and caption from the request body
        const { imageUrl, caption } = await request.json();
        if (!imageUrl) {
            return new Response(JSON.stringify({
                error: 'Image URL is required'
            }), {
                status: 400
            });
        }
        if (caption === undefined || caption === null) {
            return new Response(JSON.stringify({
                error: 'Caption is required'
            }), {
                status: 400
            });
        }
        // 4. Retrieve the user's Instagram account details from your database
        const { data: igAccount, error: dbError } = await supabase.from('instagram_accounts').select('instagram_account_id, access_token').eq('user_id', userId).single();
        if (dbError || !igAccount) {
            console.error("Supabase error fetching IG account:", dbError);
            return new Response(JSON.stringify({
                error: 'Instagram account not found. Please connect it in Settings.'
            }), {
                status: 404
            });
        }
        const { instagram_account_id: igUserId, access_token: accessToken } = igAccount;
        // 5. Call the function to post to Instagram's API
        const result = await postImageToInstagram(igUserId, imageUrl, caption, accessToken);
        return new Response(JSON.stringify(result), {
            status: 200
        });
    } catch (error) {
        console.error('API Error posting to Instagram:', error.message);
        return new Response(JSON.stringify({
            error: error.message || 'Internal Server Error'
        }), {
            status: 500
        });
    }
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__182653d1._.js.map
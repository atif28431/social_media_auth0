// Debug Script for Hashtag Generation
// Copy and paste this into your browser's console to test the API

async function testHashtagAPI() {
  console.log('Testing hashtag API...');
  
  try {
    const response = await fetch('/api/generate-hashtags', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ 
        caption: 'Having a great day at the beach with friends! 🌊☀️' 
      }),
    });

    console.log('Response status:', response.status);
    console.log('Response headers:', response.headers);

    if (!response.ok) {
      console.error('Response not OK:', response.statusText);
      const errorText = await response.text();
      console.error('Error text:', errorText);
      return;
    }

    const data = await response.json();
    console.log('API Response:', data);
    console.log('Generated hashtags:', data.hashtags);
    console.log('Categories detected:', data.categories);
    console.log('Categorized hashtags:', data.categorized);
    
  } catch (error) {
    console.error('Error calling API:', error);
  }
}

// Run the test
testHashtagAPI();

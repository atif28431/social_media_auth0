/** @type {import('next').NextConfig} */
const nextConfig = {
  transpilePackages: ['geist'],
};

export default nextConfig;

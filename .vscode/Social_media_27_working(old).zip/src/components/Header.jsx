"use client";

import { useAuth } from "@/context/AuthContext";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { SidebarTrigger } from "@/components/ui/sidebar";
import { Bell, Search, Home, LogOut, Settings } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuPortal,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

export default function Header() {
  const { isAuthenticated, logout } = useAuth();

  return (
    <header className="bg-background border-b sticky top-0 z-50 h-14 flex items-center px-4 md:px-6 w-full">
      <div className="flex items-center gap-2">
        <SidebarTrigger />
        <Link href="/" className="flex items-center gap-2 md:hidden">
          <div className="bg-primary text-primary-foreground flex h-7 w-7 items-center justify-center rounded-md">
            <Home className="h-3.5 w-3.5" />
          </div>
          <span className="font-bold text-lg">Social Poster</span>
        </Link>
      </div>
      
      <div className="flex-1 flex items-center justify-end gap-4">
        {isAuthenticated && (
          <>
            <div className="relative hidden md:flex items-center">
              <Search className="absolute left-2.5 h-4 w-4 text-muted-foreground" />
              <input 
                type="search" 
                placeholder="Search..." 
                className="h-9 w-[200px] rounded-md border border-input bg-background pl-8 pr-3 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
              />
            </div>
            <Button variant="ghost" size="icon">
              <Bell className="h-4 w-4" />
            </Button>
            <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Avatar className="h-8 w-8 border border-border cursor-pointer">
              <AvatarImage src="/avatar-placeholder.png" alt="User" />
              <AvatarFallback>U</AvatarFallback>
            </Avatar>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56" align="start">
        <DropdownMenuLabel>My Account</DropdownMenuLabel>
        <DropdownMenuGroup>
          
          
          <DropdownMenuItem>
            <Link href="/settings">
                <Button
                  variant="ghost"
                  size="sm"
                  className="flex w-full items-center justify-start gap-2 h-8"
                >
                  <Settings className="h-4 w-4" />
                  <span>Account Settings</span>
                </Button>
              </Link>
          </DropdownMenuItem>
        </DropdownMenuGroup>
        <DropdownMenuSeparator />
        <DropdownMenuItem>
          <Button
                variant="ghost"
                size="sm"
                onClick={logout}
                className="flex w-full items-center justify-start gap-2 h-8 text-red-500 hover:text-red-600 hover:bg-red-50"
              >
                <LogOut className="h-4 w-4" />
                <span>Logout</span>
              </Button>
          
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
          </>
        )}
        
        {!isAuthenticated && (
          <Link href="/login">
            <Button size="sm">Login</Button>
          </Link>
        )}
      </div>
    </header>
  );
}
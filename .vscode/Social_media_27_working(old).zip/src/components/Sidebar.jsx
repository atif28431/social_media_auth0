"use client";

import { useAuth } from "@/context/AuthContext";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Facebook, Instagram, Youtube, Settings, Hash, FileText, Calendar, LayoutDashboard, PlusCircle, LogOut, Home } from "lucide-react";

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarProvider,
  SidebarTrigger,
  SidebarSeparator,
  SidebarGroup,
  SidebarGroupLabel,
} from "@/components/ui/sidebar";

import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default function AppSidebar() {
  const { isAuthenticated, fbAccessToken, instagramAccessToken, youtubeAccessToken, logout } = useAuth();
  const pathname = usePathname();

  const connectFacebook = () => {
    const appId = process.env.NEXT_PUBLIC_FACEBOOK_APP_ID;
    const redirectUri = `${window.location.origin}/facebook-callback`;
    const scope =
      "pages_show_list,pages_manage_posts,pages_read_engagement,pages_read_user_content,public_profile,email";
    window.location.href = `https://www.facebook.com/v23.0/dialog/oauth?client_id=${appId}&redirect_uri=${encodeURIComponent(
      redirectUri
    )}&scope=${scope}&response_type=token&auth_type=rerequest`;
  };

  const connectInstagram = () => {
    const appId = process.env.NEXT_PUBLIC_INSTAGRAM_APP_ID;
    const redirectUri = `${window.location.origin}/instagram-callback`;
    const scope =
      "instagram_business_basic,instagram_business_manage_messages,instagram_business_manage_comments,instagram_business_content_publish,instagram_business_manage_insights";
    console.log("Using Instagram App ID:", appId);
    console.log("Redirect URI:", redirectUri);
    const state = crypto.randomUUID();
    localStorage.setItem("instagram_state", state);
    // Construct the authorization URL
    const authUrl = new URL("https://www.instagram.com/oauth/authorize");
    authUrl.searchParams.set("client_id", appId);
    authUrl.searchParams.set("redirect_uri", redirectUri); // No need to manually encode
    authUrl.searchParams.set("scope", scope);
    authUrl.searchParams.set("response_type", "code");
    authUrl.searchParams.set("force_reauth", "true");
    authUrl.searchParams.set("state", state);

    console.log("Instagram authorization URL:", authUrl);
    window.location.href = authUrl.toString();
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
      <Sidebar className="border-r" style={{ flexShrink: 0 }}>
        <SidebarHeader>
          <div className="flex items-center justify-between px-4 py-2">
            <Link href="/" className="flex items-center gap-2">
              <div className="bg-primary text-primary-foreground flex h-8 w-8 items-center justify-center rounded-md">
                <Home className="h-4 w-4" />
              </div>
              <span className="font-bold text-lg">Social Poster</span>
            </Link>
            
          </div>
        </SidebarHeader>
        <SidebarContent>
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton
                asChild
                isActive={pathname === "/dashboard"}
                tooltip="Dashboard"
              >
                <Link href="/dashboard" className="flex items-center gap-2">
                  <LayoutDashboard className="h-4 w-4" />
                  <span>Dashboard</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>

            <SidebarMenuItem>
              <SidebarMenuButton tooltip="Create Post">
                <div className="flex items-center gap-2">
                  <PlusCircle className="h-4 w-4" />
                  <span>Create Post</span>
                </div>
              </SidebarMenuButton>
              <SidebarMenuSub>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton
                    asChild
                    isActive={pathname === "/facebook"}
                  >
                    <Link href="/facebook" className="flex items-center gap-2">
                      <Facebook className="h-4 w-4 text-blue-600" />
                      <span>Facebook Post</span>
                    </Link>
                  </SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton
                    asChild
                    isActive={pathname === "/instagram"}
                  >
                    <Link href="/instagram" className="flex items-center gap-2">
                      <Instagram className="h-4 w-4 text-pink-600" />
                      <span>Instagram Post</span>
                    </Link>
                  </SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton
                    asChild
                    isActive={pathname === "/youtube"}
                  >
                    <Link href="/youtube" className="flex items-center gap-2">
                      <Youtube className="h-4 w-4 text-red-600" />
                      <span>YouTube Post</span>
                    </Link>
                  </SidebarMenuSubButton>
                </SidebarMenuSubItem>
              </SidebarMenuSub>
            </SidebarMenuItem>

            <SidebarMenuItem>
              <SidebarMenuButton tooltip="Tools">
                <div className="flex items-center gap-2">
                  <Settings className="h-4 w-4" />
                  <span>Tools</span>
                </div>
              </SidebarMenuButton>
              <SidebarMenuSub>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton
                    asChild
                    isActive={pathname === "/settings" && new URLSearchParams(window.location.search).get("tab") === "hashtags"}
                  >
                    <Link href="/settings?tab=hashtags" className="flex items-center gap-2">
                      <Hash className="h-4 w-4" />
                      <span>Hashtag Manager</span>
                    </Link>
                  </SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton
                    asChild
                    isActive={pathname === "/settings" && new URLSearchParams(window.location.search).get("tab") === "templates"}
                  >
                    <Link href="/settings?tab=templates" className="flex items-center gap-2">
                      <FileText className="h-4 w-4" />
                      <span>Post Templates</span>
                    </Link>
                  </SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton
                    asChild
                    isActive={pathname === "/scheduled"}
                  >
                    <Link href="/scheduled" className="flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      <span>Scheduled Posts</span>
                    </Link>
                  </SidebarMenuSubButton>
                </SidebarMenuSubItem>
              </SidebarMenuSub>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarContent>

        <SidebarFooter>
          <SidebarSeparator />
          <SidebarGroup>
            <SidebarGroupLabel>Social Accounts</SidebarGroupLabel>
            {!fbAccessToken && (
              <div className="py-1">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={connectFacebook}
                  className="flex w-full items-center gap-2"
                >
                  <Facebook className="h-4 w-4 text-blue-600" />
                  <span>Connect Facebook</span>
                </Button>
              </div>
            )}
            {!instagramAccessToken && (
              <div className="py-1">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={connectInstagram}
                  className="flex w-full items-center gap-2"
                >
                  <Instagram className="h-4 w-4 text-pink-600" />
                  <span>Connect Instagram</span>
                </Button>
              </div>
            )}
            {!youtubeAccessToken && (
              <div className="py-1">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => window.location.href = '/api/auth/youtube-auth'}
                  className="flex w-full items-center gap-2"
                >
                  <Youtube className="h-4 w-4 text-red-600" />
                  <span>Connect YouTube</span>
                </Button>
              </div>
            )}
          </SidebarGroup>
          
          <SidebarSeparator />
          
          <div className="p-4">
            <div className="flex items-center gap-3">
              <Avatar className="h-10 w-10 border border-border">
                <AvatarImage src="/avatar-placeholder.png" alt="User" />
                <AvatarFallback>U</AvatarFallback>
              </Avatar>
              <div className="flex flex-col">
                <span className="text-sm font-medium">User Account</span>
                <span className="text-xs text-muted-foreground">user@example.com</span>
              </div>
            </div>
            
            <div className="mt-3 flex flex-col gap-1">
              <Link href="/settings">
                <Button
                  variant="ghost"
                  size="sm"
                  className="flex w-full items-center justify-start gap-2 h-8"
                >
                  <Settings className="h-4 w-4" />
                  <span>Account Settings</span>
                </Button>
              </Link>
              <Button
                variant="ghost"
                size="sm"
                onClick={logout}
                className="flex w-full items-center justify-start gap-2 h-8 text-red-500 hover:text-red-600 hover:bg-red-50"
              >
                <LogOut className="h-4 w-4" />
                <span>Logout</span>
              </Button>
            </div>
          </div>
        </SidebarFooter>
      </Sidebar>
  );
}
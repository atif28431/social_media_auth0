"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { useSupabase } from "@/context/SupabaseContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import ScheduledPosts from "@/components/ScheduledPosts";
import { 
  Facebook, 
  Instagram, 
  Twitter, 
  Linkedin, 
  Calendar, 
  BarChart3, 
  Settings, 
  Plus,
  ArrowRight,
  Hash,
  FileText
} from "lucide-react";
import Link from "next/link";
import { toast } from "sonner";

export default function Dashboard() {
  const { user, isAuthenticated, fbAccessToken, instagramAccessToken } = useAuth();
  const { supabase } = useSupabase();
  const [stats, setStats] = useState({
    totalPosts: 0,
    scheduledPosts: 0,
    connectedAccounts: 0,
    drafts: 0
  });
  const [recentPosts, setRecentPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isAuthenticated) return;
    fetchDashboardData();
  }, [isAuthenticated]);

  const fetchDashboardData = async () => {
    try {
      // Fetch stats and recent posts
      // This would be implemented with real data from Supabase
      
      // Count connected accounts
      let connectedCount = 0;
      if (fbAccessToken) connectedCount++;
      if (instagramAccessToken) connectedCount++;
      
      setStats({
        totalPosts: 24, // Mock data
        scheduledPosts: 5, // Mock data
        connectedAccounts: connectedCount,
        drafts: 3 // Mock data
      });
      
      // Mock recent posts data
      setRecentPosts([
        { id: 1, platform: 'facebook', message: 'Welcome to our new product launch!', date: '2024-01-15', status: 'published' },
        { id: 2, platform: 'instagram', message: 'Behind the scenes at our office', date: '2024-01-14', status: 'scheduled' },
        { id: 3, platform: 'facebook', message: 'Thank you for your support!', date: '2024-01-13', status: 'published' }
      ]);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!isAuthenticated) {
    return <div>Loading...</div>;
  }

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const quickActions = [
    {
      title: "Post to Facebook",
      description: "Create and schedule Facebook posts",
      icon: Facebook,
      href: "/facebook",
      color: "bg-blue-500",
      connected: !!fbAccessToken
    },
    {
      title: "Post to Instagram",
      description: "Share photos and stories",
      icon: Instagram,
      href: "/instagram",
      color: "bg-pink-500",
      connected: !!instagramAccessToken
    },
    {
      title: "Manage Hashtags",
      description: "Create hashtag collections",
      icon: Hash,
      href: "/settings?tab=hashtags",
      color: "bg-purple-500",
      connected: true
    },
    {
      title: "Post Templates",
      description: "Save and reuse templates",
      icon: FileText,
      href: "/settings?tab=templates",
      color: "bg-green-500",
      connected: true
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-3xl font-bold">Dashboard</h1>
            <p className="text-muted-foreground">Welcome back, {user?.name || 'User'}!</p>
          </div>
          <Link href="/settings">
            <Button variant="outline" className="gap-2">
              <Settings className="h-4 w-4" />
              Settings
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Posts</p>
                <p className="text-2xl font-bold">{stats.totalPosts}</p>
              </div>
              <BarChart3 className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Scheduled</p>
                <p className="text-2xl font-bold">{stats.scheduledPosts}</p>
              </div>
              <Calendar className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Connected</p>
                <p className="text-2xl font-bold">{stats.connectedAccounts}</p>
              </div>
              <Settings className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Drafts</p>
                <p className="text-2xl font-bold">{stats.drafts}</p>
              </div>
              <FileText className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Quick Actions */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
              <CardDescription>
                Create content and manage your social media presence
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {quickActions.map((action, index) => {
                  const IconComponent = action.icon;
                  return (
                    <Link key={index} href={action.href}>
                      <div className="group p-4 border rounded-lg hover:shadow-md transition-all cursor-pointer">
                        <div className="flex items-start gap-3">
                          <div className={`p-2 rounded-lg ${action.color}`}>
                            <IconComponent className="h-5 w-5 text-white" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h3 className="font-medium group-hover:text-primary transition-colors">
                                {action.title}
                              </h3>
                              {action.connected && (
                                <Badge variant="secondary" className="text-xs">
                                  Ready
                                </Badge>
                              )}
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {action.description}
                            </p>
                          </div>
                          <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                        </div>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Recent Posts</CardTitle>
              <CardDescription>
                Your latest social media activity
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentPosts.map((post) => {
                  const PlatformIcon = post.platform === 'facebook' ? Facebook : Instagram;
                  return (
                    <div key={post.id} className="flex items-start gap-3 p-3 border rounded-lg">
                      <div className={`p-1 rounded ${post.platform === 'facebook' ? 'bg-blue-100' : 'bg-pink-100'}`}>
                        <PlatformIcon className={`h-4 w-4 ${post.platform === 'facebook' ? 'text-blue-600' : 'text-pink-600'}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">
                          {post.message}
                        </p>
                        <div className="flex items-center gap-2 mt-1">
                          <p className="text-xs text-muted-foreground">
                            {post.date}
                          </p>
                          <Badge 
                            variant={post.status === 'published' ? 'default' : 'secondary'}
                            className="text-xs"
                          >
                            {post.status}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  );
                })}
                
                <Link href="/scheduled">
                  <Button variant="outline" className="w-full mt-4">
                    View All Posts
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

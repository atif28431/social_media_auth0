import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

/**
 * API endpoint to handle YouTube OAuth authentication
 * This endpoint initiates the OAuth flow by redirecting to Google's authorization URL
 */
export async function GET(request) {
  try {
    // Get the redirect URI and return URL from the request
    const { searchParams } = new URL(request.url);
    const redirectUri = searchParams.get('redirect_uri') || `${process.env.APP_BASE_URL}/api/auth/youtube-callback`;
    const returnUrl = searchParams.get('return');
    
    // Google OAuth parameters
    const clientId = process.env.GOOGLE_CLIENT_ID;
    const scope = 'https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube.readonly';
    
    // Construct the authorization URL
    const authUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth');
    authUrl.searchParams.append('client_id', clientId);
    authUrl.searchParams.append('redirect_uri', redirectUri);
    authUrl.searchParams.append('response_type', 'code');
    authUrl.searchParams.append('scope', scope);
    authUrl.searchParams.append('access_type', 'offline');
    authUrl.searchParams.append('prompt', 'consent'); // Force to get refresh token
    
    // Generate a state parameter to prevent CSRF attacks
    const state = Math.random().toString(36).substring(2, 15);
    authUrl.searchParams.append('state', state);
    
    // Store the state and return URL in cookies for verification when the user returns
    const response = NextResponse.redirect(authUrl.toString());
    response.cookies.set('youtube_auth_state', state, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      maxAge: 60 * 10, // 10 minutes
      path: '/',
    });
    
    // Store the return URL if provided
    if (returnUrl) {
      response.cookies.set('youtube_return_url', returnUrl, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        maxAge: 60 * 10, // 10 minutes
        path: '/',
      });
    }
    
    return response;
  } catch (error) {
    console.error('Error initiating YouTube auth:', error);
    return NextResponse.json(
      { error: 'Failed to initiate YouTube authentication' },
      { status: 500 }
    );
  }
}
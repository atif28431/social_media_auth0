/**
 * Utility functions for YouTube API interactions
 */

/**
 * Get user's YouTube channels
 * @param {string} accessToken - The YouTube Access Token
 * @returns {Promise<Array>} - The response from YouTube with channel information
 */
export async function getUserYoutubeChannels(accessToken) {
  try {
    if (!accessToken) {
      throw new Error("No access token provided. Please connect your YouTube account.");
    }
    
    console.log("Fetching YouTube channels with token length:", accessToken ? accessToken.length : 0);
    
    const response = await fetch(
      "https://www.googleapis.com/youtube/v3/channels?part=snippet,contentDetails,statistics&mine=true",
      {
        method: "GET",
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
      }
    );

    if (!response.ok) {
      const errorData = await response.json();
      console.error("YouTube API error:", errorData);
      throw new Error(`YouTube API error: ${errorData.error?.message || response.statusText}`);
    }

    const data = await response.json();
    console.log("YouTube channels data:", data);
    
    return data.items || [];
  } catch (error) {
    console.error("Error fetching YouTube channels:", error);
    throw error;
  }
}

/**
 * Upload a video to YouTube
 * @param {string} accessToken - The YouTube Access Token
 * @param {string} title - The video title
 * @param {string} description - The video description
 * @param {string} mediaUrl - The URL of the video file
 * @param {Array} tags - Array of tags for the video
 * @param {string} categoryId - The YouTube category ID
 * @param {string} privacyStatus - The privacy status (private, unlisted, public)
 * @returns {Promise<Object>} - The response from YouTube with video details
 */
export async function uploadVideoToYoutube(
  accessToken,
  title,
  description,
  mediaUrl,
  tags = [],
  categoryId = "22", // People & Blogs by default
  privacyStatus = "public"
) {
  try {
    if (!accessToken) {
      throw new Error("No access token provided. Please connect your YouTube account.");
    }
    
    if (!mediaUrl) {
      throw new Error("No media URL provided. Please upload a video.");
    }
    
    console.log("Uploading video to YouTube:", {
      title,
      description: description ? description.substring(0, 50) + "..." : "(empty)",
      mediaUrl: mediaUrl ? "provided" : "missing",
      tags: tags.length,
      categoryId,
      privacyStatus,
      tokenLength: accessToken ? accessToken.length : 0
    });
    
    // First, fetch the video from the mediaUrl
    console.log("Fetching video from URL:", mediaUrl);
    const videoResponse = await fetch(mediaUrl);
    if (!videoResponse.ok) {
      throw new Error(
        `Failed to fetch video from URL: ${mediaUrl}, status: ${videoResponse.status}`
      );
    }
    
    const videoBlob = await videoResponse.blob();
    const videoFile = new File([videoBlob], "video.mp4", { type: "video/mp4" });
    
    // Create a FormData object to send the video file
    const formData = new FormData();
    
    // Add the metadata as a JSON blob
    const metadata = {
      snippet: {
        title,
        description,
        tags,
        categoryId,
      },
      status: {
        privacyStatus,
        selfDeclaredMadeForKids: false,
      },
    };
    
    const blob = new Blob([JSON.stringify(metadata)], { type: "application/json" });
    formData.append("metadata", blob, "metadata.json");
    formData.append("video", videoFile);
    
    // Upload the video to YouTube
    const uploadResponse = await fetch(
      "https://www.googleapis.com/upload/youtube/v3/videos?part=snippet,status&uploadType=multipart",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
        body: formData,
      }
    );
    
    if (!uploadResponse.ok) {
      const errorData = await uploadResponse.json();
      console.error("YouTube upload error:", errorData);
      throw new Error(`YouTube upload error: ${errorData.error?.message || uploadResponse.statusText}`);
    }
    
    const uploadData = await uploadResponse.json();
    console.log("YouTube upload successful:", uploadData);
    
    return uploadData;
  } catch (error) {
    console.error("Error uploading video to YouTube:", error);
    throw error;
  }
}

/**
 * Schedule a video for upload to YouTube
 * @param {string} accessToken - The YouTube Access Token
 * @param {string} title - The video title
 * @param {string} description - The video description
 * @param {string} mediaUrl - The URL of the video file
 * @param {Date} scheduledPublishTime - The time to publish the video
 * @param {Array} tags - Array of tags for the video
 * @param {string} categoryId - The YouTube category ID
 * @returns {Promise<Object>} - The response from YouTube with video details
 */
export async function scheduleVideoForYoutube(
  accessToken,
  title,
  description,
  mediaUrl,
  scheduledPublishTime,
  tags = [],
  categoryId = "22" // People & Blogs by default
) {
  try {
    if (!accessToken) {
      throw new Error("No access token provided. Please connect your YouTube account.");
    }
    
    if (!mediaUrl) {
      throw new Error("No media URL provided. Please upload a video.");
    }
    
    if (!scheduledPublishTime) {
      throw new Error("No scheduled publish time provided. Please select a time to schedule.");
    }
    
    console.log("Scheduling video for YouTube:", {
      title,
      description: description ? description.substring(0, 50) + "..." : "(empty)",
      mediaUrl: mediaUrl ? "provided" : "missing",
      scheduledPublishTime: scheduledPublishTime.toISOString(),
      tags: tags.length,
      categoryId,
      tokenLength: accessToken ? accessToken.length : 0
    });
    
    // First, fetch the video from the mediaUrl
    console.log("Fetching video from URL:", mediaUrl);
    const videoResponse = await fetch(mediaUrl);
    if (!videoResponse.ok) {
      throw new Error(
        `Failed to fetch video from URL: ${mediaUrl}, status: ${videoResponse.status}`
      );
    }
    
    const videoBlob = await videoResponse.blob();
    const videoFile = new File([videoBlob], "video.mp4", { type: "video/mp4" });
    
    // Create a FormData object to send the video file
    const formData = new FormData();
    
    // Add the metadata as a JSON blob
    const metadata = {
      snippet: {
        title,
        description,
        tags,
        categoryId,
      },
      status: {
        privacyStatus: "private", // Initially set to private
        publishAt: scheduledPublishTime.toISOString(), // Schedule time
        selfDeclaredMadeForKids: false,
      },
    };
    
    const blob = new Blob([JSON.stringify(metadata)], { type: "application/json" });
    formData.append("metadata", blob, "metadata.json");
    formData.append("video", videoFile);
    
    // Upload the video to YouTube
    const uploadResponse = await fetch(
      "https://www.googleapis.com/upload/youtube/v3/videos?part=snippet,status&uploadType=multipart",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
        body: formData,
      }
    );
    
    if (!uploadResponse.ok) {
      const errorData = await uploadResponse.json();
      console.error("YouTube upload error:", errorData);
      throw new Error(`YouTube upload error: ${errorData.error?.message || uploadResponse.statusText}`);
    }
    
    const uploadData = await uploadResponse.json();
    console.log("YouTube scheduled upload successful:", uploadData);
    
    return uploadData;
  } catch (error) {
    console.error("Error scheduling video for YouTube:", error);
    throw error;
  }
}

/**
 * Get YouTube video categories
 * @param {string} accessToken - The YouTube Access Token
 * @param {string} regionCode - The region code (e.g., 'US')
 * @returns {Promise<Array>} - The response from YouTube with category information
 */
export async function getYoutubeCategories(accessToken, regionCode = "US") {
  try {
    if (!accessToken) {
      throw new Error("No access token provided. Please connect your YouTube account.");
    }
    
    console.log("Fetching YouTube categories with token length:", accessToken ? accessToken.length : 0);
    
    const response = await fetch(
      `https://www.googleapis.com/youtube/v3/videoCategories?part=snippet&regionCode=${regionCode}`,
      {
        method: "GET",
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
      }
    );

    if (!response.ok) {
      const errorData = await response.json();
      console.error("YouTube API error:", errorData);
      throw new Error(`YouTube API error: ${errorData.error?.message || response.statusText}`);
    }

    const data = await response.json();
    console.log("YouTube categories data:", data);
    
    return data.items || [];
  } catch (error) {
    console.error("Error fetching YouTube categories:", error);
    throw error;
  }
}
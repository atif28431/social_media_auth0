import { createClient } from '@supabase/supabase-js';
import { getSession } from '@auth0/nextjs-auth0';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

export async function GET(request) {
  try {
    const session = await getSession();
    if (!session?.user) {
      return Response.json({ error: 'Not authenticated' }, { status: 401 });
    }

    const userId = session.user.sub;
    console.log('Debug: Checking tokens for user:', userId);

    // Get user session data
    const { data, error } = await supabase
      .from('user_sessions')
      .select('facebook_access_token, instagram_access_token, facebook_token_expires_at, instagram_token_expires_at, updated_at')
      .eq('user_id', userId)
      .single();

    if (error && error.code !== 'PGRST116') {
      console.error('Debug: Error fetching tokens:', error);
      return Response.json({ error: error.message }, { status: 500 });
    }

    const result = {
      userId,
      hasFacebookToken: !!data?.facebook_access_token,
      hasInstagramToken: !!data?.instagram_access_token,
      facebookTokenLength: data?.facebook_access_token?.length || 0,
      instagramTokenLength: data?.instagram_access_token?.length || 0,
      facebookExpiry: data?.facebook_token_expires_at,
      instagramExpiry: data?.instagram_token_expires_at,
      lastUpdated: data?.updated_at,
      rawData: data
    };

    console.log('Debug: Token state:', result);
    return Response.json(result);

  } catch (error) {
    console.error('Debug: Error in token debug endpoint:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
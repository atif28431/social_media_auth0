/**
 * Debug script for Facebook token endpoint
 * Run with: node debug-facebook-token.js
 */

const fetch = require('node-fetch');
require('dotenv').config({ path: '.env.local' });

async function debugFacebookToken() {
  console.log('Debugging Facebook token endpoint...');
  console.log('Environment variables:');
  console.log('- NEXT_PUBLIC_FACEBOOK_APP_ID:', process.env.NEXT_PUBLIC_FACEBOOK_APP_ID);
  console.log('- FACEBOOK_APP_SECRET:', process.env.FACEBOOK_APP_SECRET ? '✓ Set' : '✗ Not set');
  console.log('- APP_BASE_URL:', process.env.APP_BASE_URL || 'Not set, using default: http://localhost:3000');
  
  // Test URL construction
  const code = 'TEST_CODE'; // This is just for testing URL construction
  const redirectUri = `${process.env.APP_BASE_URL || 'http://localhost:3000'}/api/facebook/token`;
  const tokenUrl = `https://graph.facebook.com/v19.0/oauth/access_token?client_id=${process.env.NEXT_PUBLIC_FACEBOOK_APP_ID}&redirect_uri=${encodeURIComponent(redirectUri)}&client_secret=${process.env.FACEBOOK_APP_SECRET}&code=${code}`;
  
  console.log('\nConstructed token URL:');
  console.log(tokenUrl);
  
  // Test the endpoint directly with a mock request
  try {
    console.log('\nTesting endpoint with mock request...');
    const response = await fetch('http://localhost:3000/api/facebook/token?code=TEST_CODE&state=test-state');
    const status = response.status;
    let data;
    
    try {
      data = await response.json();
    } catch (e) {
      data = await response.text();
    }
    
    console.log('Status:', status);
    console.log('Response:', data);
  } catch (error) {
    console.error('Error testing endpoint:', error);
  }
}

debugFacebookToken().catch(console.error);
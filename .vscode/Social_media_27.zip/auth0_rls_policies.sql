-- Auth0 + Supabase RLS Policies
-- Run this in Supabase SQL Editor

-- Step 1: Create the current_user_id function in public schema
CREATE OR REPLACE FUNCTION public.current_user_id()
RETURNS text
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT COALESCE(
    -- First try to get from custom header (for Auth0)
    current_setting('request.headers', true)::json->>'x-user-id',
    -- Fallback to standard Supabase auth
    (auth.jwt() ->> 'sub'::text),
    -- Last fallback for testing
    current_setting('app.current_user_id', true)
  );
$$;

-- Step 2: Drop existing policies for facebook_pages
DROP POLICY IF EXISTS "Users can view own facebook pages" ON facebook_pages;
DROP POLICY IF EXISTS "Users can insert own facebook pages" ON facebook_pages;
DROP POLICY IF EXISTS "Users can update own facebook pages" ON facebook_pages;
DROP POLICY IF EXISTS "Users can delete own facebook pages" ON facebook_pages;
DROP POLICY IF EXISTS "Auth0 users can view own facebook pages" ON facebook_pages;
DROP POLICY IF EXISTS "Auth0 users can insert own facebook pages" ON facebook_pages;
DROP POLICY IF EXISTS "Auth0 users can update own facebook pages" ON facebook_pages;
DROP POLICY IF EXISTS "Auth0 users can delete own facebook pages" ON facebook_pages;

-- Step 3: Create new Auth0-compatible policies for facebook_pages
CREATE POLICY "Auth0 users can view own facebook pages" ON facebook_pages
  FOR SELECT USING (user_id = public.current_user_id());

CREATE POLICY "Auth0 users can insert own facebook pages" ON facebook_pages
  FOR INSERT WITH CHECK (user_id = public.current_user_id());

CREATE POLICY "Auth0 users can update own facebook pages" ON facebook_pages
  FOR UPDATE USING (user_id = public.current_user_id())
  WITH CHECK (user_id = public.current_user_id());

CREATE POLICY "Auth0 users can delete own facebook pages" ON facebook_pages
  FOR DELETE USING (user_id = public.current_user_id());

-- Step 4: Drop existing policies for user_sessions
DROP POLICY IF EXISTS "Users can view own sessions" ON user_sessions;
DROP POLICY IF EXISTS "Users can insert own sessions" ON user_sessions;
DROP POLICY IF EXISTS "Users can update own sessions" ON user_sessions;
DROP POLICY IF EXISTS "Users can delete own sessions" ON user_sessions;
DROP POLICY IF EXISTS "Auth0 users can view own sessions" ON user_sessions;
DROP POLICY IF EXISTS "Auth0 users can insert own sessions" ON user_sessions;
DROP POLICY IF EXISTS "Auth0 users can update own sessions" ON user_sessions;
DROP POLICY IF EXISTS "Auth0 users can delete own sessions" ON user_sessions;

-- Step 5: Create new Auth0-compatible policies for user_sessions
CREATE POLICY "Auth0 users can view own sessions" ON user_sessions
  FOR SELECT USING (user_id = public.current_user_id());

CREATE POLICY "Auth0 users can insert own sessions" ON user_sessions
  FOR INSERT WITH CHECK (user_id = public.current_user_id());

CREATE POLICY "Auth0 users can update own sessions" ON user_sessions
  FOR UPDATE USING (user_id = public.current_user_id())
  WITH CHECK (user_id = public.current_user_id());

CREATE POLICY "Auth0 users can delete own sessions" ON user_sessions
  FOR DELETE USING (user_id = public.current_user_id());

-- Step 6: Apply same pattern to other tables
-- For scheduled_posts table
DROP POLICY IF EXISTS "Users can manage own posts" ON scheduled_posts;
DROP POLICY IF EXISTS "Auth0 users can manage own posts" ON scheduled_posts;
CREATE POLICY "Auth0 users can manage own posts" ON scheduled_posts
  FOR ALL USING (user_id = public.current_user_id())
  WITH CHECK (user_id = public.current_user_id());

-- For instagram_accounts table  
DROP POLICY IF EXISTS "Users can manage own instagram accounts" ON instagram_accounts;
DROP POLICY IF EXISTS "Auth0 users can manage own instagram accounts" ON instagram_accounts;
CREATE POLICY "Auth0 users can manage own instagram accounts" ON instagram_accounts
  FOR ALL USING (user_id = public.current_user_id())
  WITH CHECK (user_id = public.current_user_id());

-- Step 7: Grant execute permission on the function
GRANT EXECUTE ON FUNCTION public.current_user_id() TO authenticated;
GRANT EXECUTE ON FUNCTION public.current_user_id() TO anon;

-- Step 8: Ensure RLS is enabled on all tables
ALTER TABLE facebook_pages ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE scheduled_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE instagram_accounts ENABLE ROW LEVEL SECURITY;

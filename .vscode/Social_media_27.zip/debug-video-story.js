/**
 * Debug script for Facebook video story upload issues
 * Run with: node debug-video-story.js
 */

const fetch = require('node-fetch');
require('dotenv').config({ path: '.env.local' });

async function debugVideoStoryUpload() {
  console.log('🔍 Facebook Video Story Debug Tool');
  console.log('====================================\n');

  // Check environment variables
  console.log('📋 Environment Check:');
  console.log('- NEXT_PUBLIC_FACEBOOK_APP_ID:', process.env.NEXT_PUBLIC_FACEBOOK_APP_ID ? '✅ Set' : '❌ Not set');
  console.log('- FACEBOOK_APP_SECRET:', process.env.FACEBOOK_APP_SECRET ? '✅ Set' : '❌ Not set');
  console.log('- APP_BASE_URL:', process.env.APP_BASE_URL || 'Using default: http://localhost:3000');
  console.log('');

  // You'll need to replace these with actual values from your database or localStorage
  const TEST_PAGE_ID = 'YOUR_PAGE_ID_HERE'; // Replace with actual page ID
  const TEST_ACCESS_TOKEN = 'YOUR_ACCESS_TOKEN_HERE'; // Replace with actual access token

  if (TEST_PAGE_ID === 'YOUR_PAGE_ID_HERE' || TEST_ACCESS_TOKEN === 'YOUR_ACCESS_TOKEN_HERE') {
    console.log('⚠️  Please update the TEST_PAGE_ID and TEST_ACCESS_TOKEN variables in this script');
    console.log('   You can find these in your browser console when trying to upload a video story');
    return;
  }

  try {
    // Test 1: Check token permissions
    console.log('🔐 Testing Access Token Permissions...');
    const permResponse = await fetch(
      `https://graph.facebook.com/me/permissions?access_token=${TEST_ACCESS_TOKEN}`
    );
    const permData = await permResponse.json();

    if (permData.error) {
      console.log('❌ Token validation failed:', permData.error);
      return;
    }

    console.log('✅ Token is valid');
    console.log('📝 Current permissions:');
    const permissions = permData.data || [];
    const requiredPerms = ['pages_manage_posts', 'pages_show_list', 'pages_read_engagement'];
    
    permissions.forEach(perm => {
      const isRequired = requiredPerms.includes(perm.permission);
      const icon = perm.status === 'granted' ? '✅' : '❌';
      const label = isRequired ? ' (REQUIRED)' : '';
      console.log(`   ${icon} ${perm.permission}: ${perm.status}${label}`);
    });

    const hasRequired = requiredPerms.every(perm => 
      permissions.some(p => p.permission === perm && p.status === 'granted')
    );
    console.log('\n🎯 Has all required permissions:', hasRequired ? '✅ Yes' : '❌ No');
    console.log('');

    // Test 2: Check page info
    console.log('📄 Testing Page Information...');
    const pageResponse = await fetch(
      `https://graph.facebook.com/${TEST_PAGE_ID}?fields=id,name,category,about,is_verified,fan_count,tasks&access_token=${TEST_ACCESS_TOKEN}`
    );
    const pageData = await pageResponse.json();

    if (pageData.error) {
      console.log('❌ Page info failed:', pageData.error);
    } else {
      console.log('✅ Page info retrieved successfully');
      console.log(`   📋 Name: ${pageData.name}`);
      console.log(`   📂 Category: ${pageData.category}`);
      console.log(`   ✅ Verified: ${pageData.is_verified ? 'Yes' : 'No'}`);
      console.log(`   👥 Followers: ${pageData.fan_count || 'N/A'}`);
    }
    console.log('');

    // Test 3: Test video story capability
    console.log('🎬 Testing Video Story Capability...');
    const storyTestResponse = await fetch(
      `https://graph.facebook.com/${TEST_PAGE_ID}/video_stories`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          upload_phase: 'start',
          access_token: TEST_ACCESS_TOKEN,
        }),
      }
    );

    const storyTestData = await storyTestResponse.json();

    if (storyTestData.error) {
      console.log('❌ Video story test failed:');
      console.log(`   📝 Code: ${storyTestData.error.code}`);
      console.log(`   📝 Type: ${storyTestData.error.type}`);
      console.log(`   📝 Message: ${storyTestData.error.message}`);
      
      if (storyTestData.error.error_subcode) {
        console.log(`   📝 Subcode: ${storyTestData.error.error_subcode}`);
      }
      
      if (storyTestData.error.fbtrace_id) {
        console.log(`   📝 FB Trace ID: ${storyTestData.error.fbtrace_id}`);
      }

      // Provide specific guidance
      console.log('\n🔧 Troubleshooting Guide:');
      switch (storyTestData.error.code) {
        case 200:
          console.log('   ⚠️  PERMISSION ERROR: Your app lacks permissions for video stories');
          console.log('   💡 Solution: Submit your Facebook app for review to get video story permissions');
          console.log('   🔗 Go to: https://developers.facebook.com/apps/ → Your App → App Review');
          break;
        case 100:
          console.log('   ⚠️  PARAMETER ERROR: Invalid request parameters or page configuration');
          console.log('   💡 Solution: Check if your page supports stories and verify page permissions');
          break;
        case 190:
          console.log('   ⚠️  TOKEN ERROR: Access token is invalid or expired');
          console.log('   💡 Solution: Refresh your access token or reconnect Facebook account');
          break;
        default:
          console.log('   ⚠️  UNKNOWN ERROR: Check Facebook Developer Console for app status');
          console.log('   🔗 Go to: https://developers.facebook.com/apps/');
      }
    } else {
      console.log('✅ Video story capability test passed!');
      console.log('📝 Response:', storyTestData);
      
      if (storyTestData.video_id && storyTestData.upload_url) {
        console.log('🎉 Your app CAN upload video stories!');
        console.log('   The issue might be with the video file or upload process');
      }
    }

  } catch (error) {
    console.error('❌ Debug script error:', error);
  }
}

// Instructions for running the script
console.log('📖 INSTRUCTIONS:');
console.log('1. Replace TEST_PAGE_ID and TEST_ACCESS_TOKEN with actual values');
console.log('2. Run: node debug-video-story.js');
console.log('3. Check the output for specific error details\n');

debugVideoStoryUpload().catch(console.error);

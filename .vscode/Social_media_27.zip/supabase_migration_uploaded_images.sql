-- Create uploaded_images table for storing image upload records
CREATE TABLE IF NOT EXISTS uploaded_images (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id TEXT NOT NULL,
  platform TEXT NOT NULL DEFAULT 'facebook',
  file_name TEXT NOT NULL,
  original_name TEXT NOT NULL,
  file_size INTEGER NOT NULL,
  file_type TEXT NOT NULL,
  storage_path TEXT NOT NULL,
  public_url TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_uploaded_images_user_id ON uploaded_images(user_id);
CREATE INDEX IF NOT EXISTS idx_uploaded_images_platform ON uploaded_images(platform);
CREATE INDEX IF NOT EXISTS idx_uploaded_images_created_at ON uploaded_images(created_at);

-- Create RLS (Row Level Security) policies
ALTER TABLE uploaded_images ENABLE ROW LEVEL SECURITY;

-- Policy: Users can only see their own images
CREATE POLICY "Users can view own images" ON uploaded_images
  FOR SELECT USING (auth.uid()::text = user_id);

-- Policy: Users can only insert their own images
CREATE POLICY "Users can insert own images" ON uploaded_images
  FOR INSERT WITH CHECK (auth.uid()::text = user_id);

-- Policy: Users can only update their own images
CREATE POLICY "Users can update own images" ON uploaded_images
  FOR UPDATE USING (auth.uid()::text = user_id);

-- Policy: Users can only delete their own images
CREATE POLICY "Users can delete own images" ON uploaded_images
  FOR DELETE USING (auth.uid()::text = user_id);

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_uploaded_images_updated_at
  BEFORE UPDATE ON uploaded_images
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create storage bucket if it doesn't exist
-- Note: This should be run in Supabase dashboard or via Supabase CLI
-- INSERT INTO storage.buckets (id, name, public)
-- VALUES ('social-media-images', 'social-media-images', true)
-- ON CONFLICT (id) DO NOTHING;

-- Create storage policies for the bucket
-- Note: These should be created in Supabase dashboard Storage > Policies
-- Policy: Allow authenticated users to upload images
-- CREATE POLICY "Allow authenticated uploads" ON storage.objects
--   FOR INSERT WITH CHECK (bucket_id = 'social-media-images' AND auth.role() = 'authenticated');

-- Policy: Allow users to view their own images
-- CREATE POLICY "Allow users to view own images" ON storage.objects
--   FOR SELECT USING (bucket_id = 'social-media-images' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Policy: Allow users to delete their own images
-- CREATE POLICY "Allow users to delete own images" ON storage.objects
--   FOR DELETE USING (bucket_id = 'social-media-images' AND auth.uid()::text = (storage.foldername(name))[1]);
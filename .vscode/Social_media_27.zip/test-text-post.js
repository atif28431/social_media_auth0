/**
 * Test script to verify text post functionality
 * This helps debug the "Text Post generates video" issue
 */

import { postToFacebook } from './src/utils/facebook.js';

// Configuration - Replace with your actual values
const TEST_CONFIG = {
  PAGE_ACCESS_TOKEN: 'YOUR_PAGE_ACCESS_TOKEN_HERE',
  PAGE_ID: 'YOUR_PAGE_ID_HERE',
  USER_ACCESS_TOKEN: 'YOUR_USER_ACCESS_TOKEN_HERE',
  TEST_MESSAGE: 'Test text post from debugging script'
};

async function testTextPost() {
  try {
    console.log('🧪 Starting text post test...');
    console.log('Configuration:', {
      pageId: TEST_CONFIG.PAGE_ID,
      hasPageToken: !!TEST_CONFIG.PAGE_ACCESS_TOKEN,
      hasUserToken: !!TEST_CONFIG.USER_ACCESS_TOKEN,
      messageLength: TEST_CONFIG.TEST_MESSAGE.length
    });

    // Test 1: Basic text post
    console.log('\n📝 Test 1: Basic text post');
    const result1 = await postToFacebook(
      TEST_CONFIG.PAGE_ACCESS_TOKEN,
      TEST_CONFIG.TEST_MESSAGE,
      TEST_CONFIG.PAGE_ID,
      TEST_CONFIG.USER_ACCESS_TOKEN,
      null, // onTokenRefresh
      null, // mediaUrl - explicitly null
      'text' // mediaType - explicitly text
    );
    console.log('✅ Test 1 Result:', result1);

    // Test 2: Text post with explicit parameters
    console.log('\n📝 Test 2: Text post with all explicit null parameters');
    const result2 = await postToFacebook(
      TEST_CONFIG.PAGE_ACCESS_TOKEN,
      TEST_CONFIG.TEST_MESSAGE + ' (Test 2)',
      TEST_CONFIG.PAGE_ID,
      TEST_CONFIG.USER_ACCESS_TOKEN,
      null, // onTokenRefresh
      null, // mediaUrl
      'text' // mediaType
    );
    console.log('✅ Test 2 Result:', result2);

    // Test 3: Check what happens with undefined mediaType
    console.log('\n📝 Test 3: Text post with undefined mediaType (should default to text)');
    const result3 = await postToFacebook(
      TEST_CONFIG.PAGE_ACCESS_TOKEN,
      TEST_CONFIG.TEST_MESSAGE + ' (Test 3)',
      TEST_CONFIG.PAGE_ID,
      TEST_CONFIG.USER_ACCESS_TOKEN,
      null, // onTokenRefresh
      null, // mediaUrl
      undefined // mediaType - should default to 'text'
    );
    console.log('✅ Test 3 Result:', result3);

    console.log('\n🎉 All tests completed successfully!');

  } catch (error) {
    console.error('❌ Test failed:', error);
    console.error('Error details:', {
      name: error.name,
      message: error.message,
      stack: error.stack
    });
  }
}

// Instructions
console.log(`
🔧 Facebook Text Post Debug Tool
================================

Before running this script:
1. Replace the placeholder values in TEST_CONFIG with your actual tokens
2. Make sure you have a valid Facebook page access token
3. Ensure your page ID is correct

To run this test:
node test-text-post.js

This will help identify if the issue is:
- In the API calls
- In the token handling
- In the parameter passing
- Something else entirely

Check the console output for detailed debugging information.
`);

// Uncomment the line below to run the test (after configuring tokens)
// testTextPost();

export { testTextPost };

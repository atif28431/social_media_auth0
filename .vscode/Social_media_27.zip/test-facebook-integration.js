/**
 * Test script to verify Facebook integration
 * Run this with: node test-facebook-integration.js
 */

const { createClient } = require('@supabase/supabase-js');

// Test configuration
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  console.error('Missing Supabase environment variables');
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

async function testFacebookIntegration() {
  console.log('🧪 Testing Facebook Integration...');
  
  try {
    // Test 1: Check if facebook_pages table exists and is accessible
    console.log('\n1. Testing facebook_pages table access...');
    const { data: pages, error: pagesError } = await supabase
      .from('facebook_pages')
      .select('*')
      .limit(1);
    
    if (pagesError) {
      console.error('❌ Error accessing facebook_pages table:', pagesError);
    } else {
      console.log('✅ facebook_pages table is accessible');
      console.log('   Sample data structure:', pages.length > 0 ? Object.keys(pages[0]) : 'No data');
    }
    
    // Test 2: Check if user_sessions table exists and is accessible
    console.log('\n2. Testing user_sessions table access...');
    const { data: sessions, error: sessionsError } = await supabase
      .from('user_sessions')
      .select('user_id, facebook_access_token')
      .limit(1);
    
    if (sessionsError) {
      console.error('❌ Error accessing user_sessions table:', sessionsError);
    } else {
      console.log('✅ user_sessions table is accessible');
      console.log('   Sample data structure:', sessions.length > 0 ? Object.keys(sessions[0]) : 'No data');
    }
    
    // Test 3: Test Facebook API endpoint
    console.log('\n3. Testing Facebook API endpoint...');
    try {
      const response = await fetch('http://localhost:3000/api/facebook/token', {
        method: 'GET'
      });
      
      if (response.ok) {
        console.log('✅ Facebook API endpoint is accessible');
      } else {
        console.log('⚠️  Facebook API endpoint returned:', response.status, response.statusText);
      }
    } catch (fetchError) {
      console.error('❌ Error accessing Facebook API endpoint:', fetchError.message);
    }
    
    console.log('\n🎉 Facebook integration test completed!');
    
  } catch (error) {
    console.error('❌ Test failed:', error);
  }
}

// Run the test
testFacebookIntegration();